import React, { useState } from "react";
import Navbar from "./components/Navbar";
import AddTask from "./components/AddTask";
import TaskList from "./components/TaskList";
import "./App.css";

function App() {
  const [refresh, setRefresh] = useState(false);
  const handleRefresh = () => setRefresh(!refresh);

  return (
    <div className="app">
      <Navbar />
      <main className="main">
        <AddTask onTaskAdded={handleRefresh} />
        <TaskList refresh={refresh} />
      </main>
    </div>
  );
}

export default App;
