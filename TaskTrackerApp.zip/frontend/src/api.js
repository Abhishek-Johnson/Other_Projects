const API_BASE = "http://localhost:5000/api/tasks";

export const fetchTasks = async () => {
  const res = await fetch(API_BASE);
  return await res.json();
};

export const addTask = async (task) => {
  await fetch(API_BASE, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(task),
  });
};

export const updateTaskStatus = async (id, status) => {
  await fetch(`${API_BASE}/${id}/status`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status }),
  });
};

export const deleteTask = async (id) => {
  await fetch(`${API_BASE}/${id}`, { method: "DELETE" });
};

export const exportTasksCSV = () => {
  window.open(`${API_BASE}/export`, "_blank");
};
