import React from "react";
import { exportTasksCSV } from "../api";

function Navbar() {
  return (
    <nav className="navbar">
      <h1>📝 Task Tracker</h1>
      <button className="export-btn" onClick={exportTasksCSV}>
        📦 Export CSV
      </button>
    </nav>
  );
}

export default Navbar;
