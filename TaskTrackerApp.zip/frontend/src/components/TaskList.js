import React, { useEffect, useState } from "react";
import { fetchTasks, updateTaskStatus, deleteTask } from "../api";

function TaskList({ refresh }) {
  const [tasks, setTasks] = useState([]);

  const loadTasks = async () => {
    const data = await fetchTasks();
    setTasks(data);
  };

  useEffect(() => {
    loadTasks();
  }, [refresh]);

  const toggleStatus = async (task) => {
    const newStatus = task.status === "Pending" ? "Done" : "Pending";
    await updateTaskStatus(task.id, newStatus);
    loadTasks();
  };

  const removeTask = async (id) => {
    if (!window.confirm("Are you sure you want to delete this task?")) return;
    await deleteTask(id);
    loadTasks();
  };

  return (
    <div className="task-list">
      {tasks.length === 0 ? (
        <p className="empty">No tasks yet.</p>
      ) : (
        tasks.map((task) => (
          <div className={`task-card ${task.status.toLowerCase()}`} key={task.id}>
            <h3>
              {task.title}{" "}
              <span className="status">
                [{task.status}]
              </span>
            </h3>
            <p>{task.description || "—"}</p>
            <div className="meta">
              <span>📅 {task.due_date ? new Date(task.due_date).toLocaleDateString() : "No due date"}</span>
              <span>🔥 {task.priority}</span>
            </div>
            <div className="actions">
              <button onClick={() => toggleStatus(task)}>Toggle</button>
              <button className="delete" onClick={() => removeTask(task.id)}>Delete</button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default TaskList;
