import React, { useState } from "react";
import { addTask } from "../api";

function AddTask({ onTaskAdded }) {
  const [task, setTask] = useState({
    title: "",
    description: "",
    priority: "Medium",
    due_date: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!task.title.trim()) return alert("Please enter a title");
    await addTask(task);
    setTask({ title: "", description: "", priority: "Medium", due_date: "" });
    onTaskAdded();
  };

  return (
    <form className="add-task" onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Title"
        value={task.title}
        onChange={(e) => setTask({ ...task, title: e.target.value })}
      />
      <input
        type="text"
        placeholder="Description"
        value={task.description}
        onChange={(e) => setTask({ ...task, description: e.target.value })}
      />
      <select
        value={task.priority}
        onChange={(e) => setTask({ ...task, priority: e.target.value })}
      >
        <option>Low</option>
        <option>Medium</option>
        <option>High</option>
      </select>
      <input
        type="date"
        value={task.due_date}
        onChange={(e) => setTask({ ...task, due_date: e.target.value })}
      />
      <button type="submit">Add Task</button>
    </form>
  );
}

export default AddTask;
