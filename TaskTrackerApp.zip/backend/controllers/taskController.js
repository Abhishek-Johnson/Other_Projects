import db from "../db.js";
import { validationResult } from "express-validator";
import { Parser } from "json2csv";

export const getTasks = (req, res) => {
  const { status, priority, sortBy, order = "ASC", page = 1, limit = 5 } = req.query;

  let query = "SELECT * FROM tasks WHERE 1=1";
  let params = [];

  if (status) {
    query += " AND status = ?";
    params.push(status);
  }

  if (priority) {
    query += " AND priority = ?";
    params.push(priority);
  }

  if (sortBy) query += ` ORDER BY ${sortBy} ${order}`;
  else query += " ORDER BY id DESC";

  const offset = (page - 1) * limit;
  query += ` LIMIT ${limit} OFFSET ${offset}`;

  db.query(query, params, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

export const createTask = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

  const { title, description, status, priority, due_date } = req.body;
  const query =
    "INSERT INTO tasks (title, description, status, priority, due_date) VALUES (?, ?, ?, ?, ?)";
  db.query(query, [title, description, status, priority, due_date], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Task created successfully", id: result.insertId });
  });
};

export const updateTask = (req, res) => {
  const { id } = req.params;
  const { title, description, status, priority, due_date } = req.body;
  const query =
    "UPDATE tasks SET title=?, description=?, status=?, priority=?, due_date=? WHERE id=?";
  db.query(query, [title, description, status, priority, due_date, id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Task updated successfully" });
  });
};

export const deleteTask = (req, res) => {
  const { id } = req.params;
  const query = "DELETE FROM tasks WHERE id=?";
  db.query(query, [id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Task deleted successfully" });
  });
};

export const exportTasks = (req, res) => {
  db.query("SELECT * FROM tasks", (err, results) => {
    if (err) return res.status(500).json({ error: err.message });

    const parser = new Parser();
    const csv = parser.parse(results);

    res.header("Content-Type", "text/csv");
    res.attachment("tasks.csv");
    res.send(csv);
  });
};
