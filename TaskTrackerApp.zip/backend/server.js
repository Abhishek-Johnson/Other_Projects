import express from "express";
import cors from "cors";
import mysql from "mysql2";
import dotenv from "dotenv";
import { Parser } from "json2csv";
import fs from "fs";
import path from "path";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Database connection
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT
});

db.connect(err => {
  if (err) {
    console.error("Database connection failed:", err.message);
  } else {
    console.log("Connected to MySQL Database");
  }
});

// Root route
app.get("/", (req, res) => {
  res.send("Task Tracker Backend is running");
});

// Fetch tasks
app.get("/api/tasks", (req, res) => {
  const { page = 1, limit = 10, sortBy = "id", order = "DESC" } = req.query;
  const offset = (page - 1) * limit;

  const query = `SELECT * FROM tasks ORDER BY ${sortBy} ${order} LIMIT ${limit} OFFSET ${offset}`;

  db.query(query, (err, results) => {
    if (err) {
      console.error("Error fetching tasks:", err);
      return res.status(500).json({ error: "Error fetching tasks" });
    }
    res.json(results);
  });
});

// Add new task
app.post("/api/tasks", (req, res) => {
  const { title, description, status = "Pending", priority = "Medium", due_date } = req.body;
  if (!title) return res.status(400).json({ error: "Title is required" });

  const query = due_date
    ? "INSERT INTO tasks (title, description, status, priority, due_date, created_at) VALUES (?, ?, ?, ?, ?, NOW())"
    : "INSERT INTO tasks (title, description, status, priority, created_at) VALUES (?, ?, ?, ?, NOW())";

  const values = due_date
    ? [title, description, status, priority, due_date]
    : [title, description, status, priority];

  db.query(query, values, (err, result) => {
    if (err) {
      console.error("Error adding task:", err);
      return res.status(500).json({ error: "Failed to add task" });
    }
    res.json({ message: "Task added", id: result.insertId });
  });
});

// Update task
app.put("/api/tasks/:id", (req, res) => {
  const { id } = req.params;
  const { title, description, status, priority, due_date } = req.body;

  const query = "UPDATE tasks SET title=?, description=?, status=?, priority=?, due_date=? WHERE id=?";
  db.query(query, [title, description, status, priority, due_date, id], err => {
    if (err) {
      console.error("Error updating task:", err);
      return res.status(500).json({ error: "Failed to update task" });
    }
    res.json({ message: "Task updated" });
  });
});

// Update only task status
app.put("/api/tasks/:id/status", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  db.query("UPDATE tasks SET status=? WHERE id=?", [status, id], err => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Status updated" });
  });
});

// Delete task
app.delete("/api/tasks/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM tasks WHERE id=?", [id], err => {
    if (err) {
      console.error("Error deleting task:", err);
      return res.status(500).json({ error: "Failed to delete task" });
    }
    res.json({ message: "Task deleted" });
  });
});

// Export tasks as CSV
app.get("/api/tasks/export", (req, res) => {
  const { status, priority } = req.query;
  let query = "SELECT * FROM tasks";
  const filters = [];

  if (status) filters.push(`status='${status}'`);
  if (priority) filters.push(`priority='${priority}'`);
  if (filters.length) query += " WHERE " + filters.join(" AND ");

  db.query(query, (err, results) => {
    if (err) {
      console.error("Error exporting tasks:", err);
      return res.status(500).json({ error: "Failed to export tasks" });
    }

    const fields = ["id", "title", "description", "status", "priority", "due_date", "created_at"];
    const parser = new Parser({ fields });
    const csv = parser.parse(results);
    const filePath = path.join(process.cwd(), "tasks_export.csv");

    fs.writeFileSync(filePath, csv);
    res.download(filePath, "tasks_export.csv", () => fs.unlinkSync(filePath));
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
