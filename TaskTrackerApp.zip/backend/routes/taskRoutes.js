import express from "express";
import { body } from "express-validator";
import {
  getTasks,
  createTask,
  updateTask,
  deleteTask,
  exportTasks,
} from "../controllers/taskController.js";

const router = express.Router();

router.get("/", getTasks);
router.post(
  "/",
  [body("title").notEmpty().withMessage("Title is required")],
  createTask
);
router.put("/:id", updateTask);
router.delete("/:id", deleteTask);
router.get("/export", exportTasks);

export default router;
